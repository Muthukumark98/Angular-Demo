import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  LoginForms: FormGroup
  repeatpass: string | undefined;
  title = "given number"

  // ngOnInit(): void {
  //   throw new Error('Method not implemented.');
  // }
  password: string | undefined;
  username: string | undefined;

  constructor(private router: Router) {
    this.LoginForms = new FormGroup({
      firstname: new FormControl("",[Validators.required,Validators.minLength(3),Validators.pattern("[a-zA-Z].*")]),
      pwd: new FormControl('',[Validators.required]),
  })
   }

 
  onSubmit(value: any) {
    // this.LoginForms.value
    this.router.navigate(['/elp'])
    console.log(this.LoginForms.value)
  }
  
  // submit(login: any){
  //   console.log("login successful",login)
  // }
  


get FirstName(): FormControl{
  return this.LoginForms.get("firstname") as FormControl;
}

get pwd(): FormControl{
  return this.LoginForms.get("pwd") as FormControl;
}

// registerSubmited() {

 
//   console.log(this.LoginForms.get("firstname"));
// }


}
