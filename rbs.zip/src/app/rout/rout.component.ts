import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-rout',
  templateUrl: './rout.component.html',
  styleUrls: ['./rout.component.scss']
})
export class RoutComponent implements OnInit {

  constructor(private activatedRoute : ActivatedRoute, private router: Router) { }

  // openpersonal() {
  //   this.router.navigate(['details'], {relativeTo: this.activatedRoute})
  // }

  // openaddress() {
  //   this.router.navigate(['address'], {relativeTo: this.activatedRoute})
  // }

  ngOnInit(): void {
  }


}
