import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit {

  //addressForm: FormGroup;
  // State: any = ['TamilNadu', 'Karnataka', 'Kerala', 'AndhraPradhesh']
  // City: any = ['Chennai', 'Bangalore', 'Calicut', 'Guntur'];
 
  stateList: Array<any> = [
    { name: 'TamilNadu', cities: ['Chennai', 'Thanjavur', 'Cuddalore', 'Coimbatore'] },
    { name: 'Karnataka', cities: ['Bangalore'] },
    { name: 'Kerala', cities: ['Calicut', 'Ernakulam', 'Kochi'] },
    { name: 'AndhraPradhesh', cities: ['Guntur'] },
  ];
  cities: Array<any> = []
  formValue : any
  data: any;
  addressForm : FormGroup;
  x:any
  public isSameAddressControl: FormControl = new FormControl(false);
  errormsg: string | undefined;
    constructor(private fb: FormBuilder) {
      this.addressForm = this.fb.group({
        permanentaddress:  this.fb.group({
          address1: '',
          address2: '',
          state: '',
          city: '',
          landmark: '',
          pincode: ''
        }),
        presentaddress: this.fb.group({
          address1: '',
          address2: '',
          state: '',
          city: '',
          landmark: '',
          pincode: ''
        })
      });
     }
    changeCountry($event : any) {
      let a = $event.target.value
      console.log("check ",a);
      this.cities = this.stateList.find(con => con.name == a).cities;
      console.log("selected ",this.cities);
    }
    ngOnInit() {
    }
    onSubmit(value: any) {
      console.log(value)
      localStorage.setItem('form-data', JSON.stringify(this.addressForm.value));
    }
    updatePresentAddress(){
      this.formValue = JSON.parse(localStorage.getItem('form-data') || '{}')
      console.log(this.formValue);
      // this.formValue.get('presentaddress').setValue(this.[0].address1);
      this.addressForm.get('presentaddress')?.get('address1')?.setValue(this.formValue.permanentaddress.address1);
      this.addressForm.get('presentaddress')?.get('address2')?.setValue(this.formValue.permanentaddress.address2);
      this.addressForm.get('presentaddress')?.get('state')?.setValue(this.formValue.permanentaddress.state);
      this.addressForm.get('presentaddress')?.get('city')?.setValue(this.formValue.permanentaddress.city);
      this.addressForm.get('presentaddress')?.get('landmark')?.setValue(this.formValue.permanentaddress.landmark);
      this.addressForm.get('presentaddress')?.get('pincode')?.setValue(this.formValue.permanentaddress.pincode);
      console.log(this.formValue.permanentaddress);
    }
  


    addressFor = new FormGroup({
      
      address1: new FormControl("",[Validators.required]),
      address2: new FormControl("",[Validators.required])
  
    });
  
  
    get address1(): FormControl{
      return this.addressForm.get("address1") as FormControl;
    }
    get address2(): FormControl{
      return this.addressForm.get("address2") as FormControl;
    }

    // error(q:any){
    //   if(q ==null){
    //     this.errormsg = "field required"
    //   }
    // }






}
