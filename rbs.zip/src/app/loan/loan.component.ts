import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.scss']
})
export class LoanComponent implements OnInit {

  loandetailsform!:FormGroup;


  constructor( ) { 

  }

  ngOnInit(): void {

    this.loandetailsform = new FormGroup({
      loanamount:new FormControl('',[Validators.required]),
      roi:new FormControl('',[Validators.required]),
      address:new FormGroup(
        {
          address1:new FormControl('',[Validators.required]),
          address2:new FormControl('',[Validators.required])
        }
      )
    })

  }

}
