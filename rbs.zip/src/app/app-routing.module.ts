import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddressComponent } from './address/address.component';
import { DetailsComponent } from './details/details.component';
import { ElpComponent } from './elp/elp.component';
import { IncomeComponent } from './income/income.component';
import { KycComponent } from './kyc/kyc.component';
import { LoanComponent } from './loan/loan.component';
import { LoginComponent } from './login/login.component';
import { RoutComponent } from './rout/rout.component';

const routes: Routes = [
  {path:'', redirectTo: 'login', pathMatch: 'full'},
  {path:'login',component: LoginComponent},
  {path:'elp',component: ElpComponent},
  {path:'rout',component: RoutComponent,children:[
    {path:'address',component:AddressComponent},
    {path:'details',component:DetailsComponent},
    {path:'',redirectTo:'/rout/details',pathMatch:'full'},
    {path:'income',component:IncomeComponent},
    {path: 'kyc',component: KycComponent},
    {path:'loan',component:LoanComponent},
  ]}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
