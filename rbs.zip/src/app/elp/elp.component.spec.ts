import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElpComponent } from './elp.component';

describe('ElpComponent', () => {
  let component: ElpComponent;
  let fixture: ComponentFixture<ElpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ElpComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ElpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
