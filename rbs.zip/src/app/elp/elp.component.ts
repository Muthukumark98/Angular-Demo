import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elp',
  templateUrl: './elp.component.html',
  styleUrls: ['./elp.component.scss']
})
export class ElpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
