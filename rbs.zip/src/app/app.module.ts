import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { ElpComponent } from './elp/elp.component';
import { DetailsComponent } from './details/details.component';
import { AddressComponent } from './address/address.component';
import { KycComponent } from './kyc/kyc.component';
import { IncomeComponent } from './income/income.component';
import { LoanComponent } from './loan/loan.component';
import { RoutComponent } from './rout/rout.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ElpComponent,
    DetailsComponent,
    AddressComponent,
    KycComponent,
    IncomeComponent,
    LoanComponent,
    RoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
