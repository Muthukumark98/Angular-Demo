import { Component, HostListener, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  
  title = "given number"
  repeatpass: string = 'none';
  static value: any;
  loginSubmited: any;
  pwdValue: any;
  
  constructor(){
    var content1 = document.getElementById("content1");
    var content1 = document.getElementById("content2");
    var btn1 = document.getElementById("btn1");
    var btn2 = document.getElementById("btn2");
  
  }
  openpersonal(){
    var content1 = document.getElementById("content1");
    var content1 = document.getElementById("content2");
    var btn1 = document.getElementById("btn1");
    var btn2 = document.getElementById("btn2");

  }


  ngOnInit(): void {

    console.log(this.LoginForms.controls['firstname'].value )
  }

  LoginForms = new FormGroup({
    firstname: new FormControl("",[Validators.required,Validators.minLength(3),Validators.pattern("[a-zA-Z].*")]),
    lastname: new FormControl("",[Validators.required,Validators.minLength(3),Validators.pattern("[a-zA-Z].*")]),
    email: new FormControl("",[Validators.required,Validators.pattern("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$")]),
    mobile: new FormControl("",[Validators.required,Validators.maxLength(10),Validators.minLength(10),Validators.pattern("^(0|[1-9][0-9]*)$")]),
    gender: new FormControl("",[Validators.required]),
    pwd: new FormControl("",[Validators.required,Validators.minLength(6),Validators.maxLength(12),Validators.pattern("^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$")]),
    cpwd: new FormControl("",[Validators.required,Validators.minLength(6),Validators.maxLength(12),Validators.pattern("^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$")]),
    edu: new FormControl("",[Validators.required]),
    emp: new FormControl("",[Validators.required]),
    age: new FormControl("",[Validators.required])


  });





  // @HostListener('click')
  // match(cpwd:any){
  //   let test="";
  //   if(cpwd == ""){
  //     this.LoginForms.setValue('pwd);
  //   }
  // }

  registerSubmited (){

    if(this.pwd.value == this.cpwd.value){
      console.log(this.LoginForms.valid);
      this.repeatpass = 'none'
    }else{
      this.repeatpass = 'inline'
    }
    console.log(this.LoginForms.value);
  }


 get FirstName(): FormControl{
   return this.LoginForms.get("firstname") as FormControl;
  }
  get LastName(): FormControl{
    return this.LoginForms.get("lastname") as FormControl;
  }
  get Email(): FormControl{
    return this.LoginForms.get("email") as FormControl;
  }
  get Mobile(): FormControl{
    return this.LoginForms.get("mobile") as FormControl;
  }
  get Gender(): FormControl{
    return this.LoginForms.get("gender") as FormControl;
  }
  get pwd(): FormControl{
    return this.LoginForms.get("pwd") as FormControl;
  }

  get cpwd(): FormControl{
    return this.LoginForms.get("cpwd") as FormControl;
  }
  get edu(): FormControl{
    return this.LoginForms.get("edu") as FormControl;
  }

  get emp():FormControl{
    return this.LoginForms.get("emp") as FormControl;
  }

  get age(): FormControl{
    return this.LoginForms.get("age") as FormControl;
  }

  }



